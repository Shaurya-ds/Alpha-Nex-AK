# Alpha Nex - Main Application Entry Point
# This file serves as the WSGI entry point for production deployment
from app import app  # noqa: F401
